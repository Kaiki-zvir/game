# Aprenda JavaScript criando um jogo

Código da série no Youtube https://www.youtube.com/playlist?list=PLB7wuPF7rlcmyy5S_js6NIJFLYb-9D6c2